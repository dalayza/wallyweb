define({
  "name": "krushwebapi",
  "version": "1.0.0",
  "description": "Krushweb API",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-01-14T12:57:09.329Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});

define({
  "name": "krushwebapi",
  "version": "1.0.0",
  "description": "Krushweb API",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-03-19T13:32:35.045Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
